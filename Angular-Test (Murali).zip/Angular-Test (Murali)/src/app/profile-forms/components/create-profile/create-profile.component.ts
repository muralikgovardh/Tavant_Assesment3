import { Component, OnInit } from '@angular/core';
import { CreateProfile } from '../../models/create-profile';
import { Router } from '@angular/router';
import { CreateProfileService } from '../../services/create-profile.service';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  createProfile: CreateProfile = new CreateProfile();
  constructor(
    private router: Router,
    private createProfileService: CreateProfileService
  ) {}

  ngOnInit(): void {}
  createProfileSubmit() {
    this.createProfileService.createProfile(this.createProfile).subscribe(
      (res) => {
        console.log(localStorage.getItem('token'));
        console.log('created profile section');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log('error in create profile section');
      }
    );
  }
}
