export class CreateProfile {
  company: String | undefined;
  website: String | undefined;
  location: String | undefined;
  status: String | undefined;
  skills: String | undefined;
  githubusername: String | undefined;
  bio: String | undefined;
  twitter: String | undefined;
  facebook: String | undefined;
  linkedin: String | undefined;
  youtube: String | undefined;
  instagram: String | undefined;
}
