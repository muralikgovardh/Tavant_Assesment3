import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class CreateProfileService {
  constructor(private http: HttpClient) {}
  createProfile(data: any): Observable<any> {
    return this.http.post('/api/profile', data);
  }
  getProfile(): Observable<any> {
    return this.http.get('/api/profile');
  }
}
