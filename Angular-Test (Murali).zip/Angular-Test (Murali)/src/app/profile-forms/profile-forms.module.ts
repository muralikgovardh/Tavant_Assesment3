import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileFormsRoutingModule } from './profile-forms-routing.module';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CreateProfileService } from './services/create-profile.service';

@NgModule({
  declarations: [CreateProfileComponent],
  imports: [
    CommonModule,
    ProfileFormsRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [CreateProfileService],
})
export class ProfileFormsModule {}
