import { Component, OnInit } from '@angular/core';
import { Register } from '../../models/register';
import { ServicesService } from '../../services/services.service';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();
  constructor(private authService: ServicesService, private router: Router) {}

  registerSubmit() {
    // a submit method when submit button is pressed in the form.
    const newUser: any = {
      name: this.register.name, // assign values to respective fields
      email: this.register.email,
      password: this.register.password,
    };
    console.log(JSON.stringify(this.register));

    this.authService.registerUser(newUser).subscribe(
      //register the user according to the credentials
      (res) => {
        // if sucessful registration takes place
        console.log('success in register');
        this.router.navigate(['/dashboard']); // navigate to dashboard
        console.log(JSON.stringify(res.token));
        localStorage.setItem('token', res.token); // set token
      },
      (err) => {
        console.log('in errors of register');
      }
    );
  }
  ngOnInit(): void {}
}
