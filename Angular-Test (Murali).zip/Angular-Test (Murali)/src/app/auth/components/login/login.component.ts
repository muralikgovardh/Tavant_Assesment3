import { Component, OnInit } from '@angular/core';
import { Login } from '../../models/login';
import { Router } from '@angular/router';
import { ServicesService } from '../../services/services.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();
  constructor(private router: Router, private authService: ServicesService) {}

  loginSubmit() {
    // a submit method when submit button is pressed in the form.
    const newUser: any = {
      email: this.login.email, // assign values to respective fields
      password: this.login.password,
    };
    console.log(JSON.stringify(this.login));
    this.authService.loginUser(newUser).subscribe(
      // login the new user wrt to the specific details
      (res) => {
        console.log('user logged in');
        this.router.navigate(['/dashboard']); // route the user to dashboard after successfull login
        console.log(JSON.stringify(res.token));
        localStorage.setItem('token', res.token); // set the token value to localStorage
      },
      (err) => {
        console.log('login error'); // throw error
      }
    );
  }

  ngOnInit(): void {}
}
