export class Register {
  name: String | undefined;
  email: string | undefined;
  password: string | undefined;
  password2: string | undefined;
}
