export class Login {
  email: string | undefined;
  password: string | undefined;
}
